Set fso = CreateObject("Scripting.FileSystemObject")
Set app = CreateObject("Shell.Application")
Set sh  = CreateObject("WScript.Shell")

Function Exists(p)
  Exists = fso.FileExists(p)
End Function

root = fso.GetParentFolderName(WScript.ScriptFullName)

Dim candidates(9)
candidates(0) = root & "\App\FrameX Panel.hta"
candidates(1) = root & "\App\FRAMEX Panel.hta"
candidates(2) = root & "\FrameX Panel.hta"
candidates(3) = root & "\FRAMEX Panel.hta"
candidates(4) = root & "\FRAMEX_PANEL\App\FrameX Panel.hta"
candidates(5) = root & "\FRAMEX_PANEL\App\FRAMEX Panel.hta"
candidates(6) = root & "\FrameX Tweaks Ultimate\App\FrameX Panel.hta"
candidates(7) = fso.GetParentFolderName(root) & "\App\FrameX Panel.hta"
candidates(8) = fso.GetParentFolderName(root) & "\App\FRAMEX Panel.hta"

hta = ""
For i = 0 To 8
  If Exists(candidates(i)) Then
    hta = candidates(i)
    Exit For
  End If
Next

If hta = "" Then
  msg = "Could not find FrameX Panel.hta" & vbCrLf & vbCrLf
  msg = msg & "Looked next to this launcher:" & vbCrLf & root & vbCrLf & vbCrLf
  msg = msg & "Extract the WHOLE zip first, then open the VBS."
  MsgBox msg, 16, "FRAMEX"
  WScript.Quit 1
End If

appDir = fso.GetParentFolderName(hta)
pkgDir = fso.GetParentFolderName(appDir)
If fso.GetFileName(appDir) <> "App" Then pkgDir = appDir

ult = pkgDir & "\Ultimate"
If Not fso.FolderExists(ult) Then
  If fso.FolderExists(appDir & "\Ultimate") Then ult = appDir & "\Ultimate"
End If

If fso.FolderExists(ult) Then
  sh.Run "cmd /c attrib +h +s """ & ult & """", 0, True
End If

' Launch elevated with package folder as working directory
pending = fso.GetParentFolderName(hta) & "\FrameX Panel.new.hta"
If fso.FileExists(pending) Then
  On Error Resume Next
  fso.CopyFile pending, hta, True
  If Err.Number = 0 Then fso.DeleteFile pending, True
  Err.Clear
  On Error GoTo 0
End If

app.ShellExecute "mshta.exe", """" & hta & """", pkgDir, "runas", 1
