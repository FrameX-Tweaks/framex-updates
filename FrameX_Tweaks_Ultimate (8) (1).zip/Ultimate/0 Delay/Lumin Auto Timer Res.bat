��
@echo off
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager\kernel" /v GlobalTimerResolutionRequests /t REG_DWORD /d 1 /f
mkdir C:\Lumin
chcp 65001
cd %temp%
                                                                            mode con: cols=165 lines=30
																			                                    color 50
        title Lumin Auto Timer Res
		    cls
			
    echo  ▄█       ███    █▄    ▄▄▄▄███▄▄▄▄    ▄█  ███▄▄▄▄            ███      ▄█    ▄▄▄▄███▄▄▄▄      ▄████████    ▄████████         ▄████████    ▄████████    ▄████████ 
    echo ███       ███    ███ ▄██▀▀▀███▀▀▀██▄ ███  ███▀▀▀██▄      ▀█████████▄ ███  ▄██▀▀▀███▀▀▀██▄   ███    ███   ███    ███        ███    ███   ███    ███   ███    ███ 
                                echo ███       ███    ███ ███   ███   ███ ███▌ ███   ███         ▀███▀▀██ ███▌ ███   ███   ███   ███    █▀    ███    ███        ███    ███   ███    █▀    ███    █▀  
                                echo ███       ███    ███ ███   ███   ███ ███▌ ███   ███          ███   ▀ ███▌ ███   ███   ███  ▄███▄▄▄      ▄███▄▄▄▄██▀       ▄███▄▄▄▄██▀  ▄███▄▄▄       ███        
                                echo ███       ███    ███ ███   ███   ███ ███▌ ███   ███          ███     ███▌ ███   ███   ███ ▀▀███▀▀▀     ▀▀███▀▀▀▀▀        ▀▀███▀▀▀▀▀   ▀▀███▀▀▀     ▀███████████ 
                                               echo ███       ███    ███ ███   ███   ███ ███  ███   ███          ███     ███  ███   ███   ███   ███    █▄  ▀███████████      ▀███████████   ███    █▄           ███ 
                                               echo ███▌    ▄ ███    ███ ███   ███   ███ ███  ███   ███          ███     ███  ███   ███   ███   ███    ███   ███    ███        ███    ███   ███    ███    ▄█    ███ 
                                               echo █████▄▄██ ████████▀   ▀█   ███   █▀  █▀    ▀█   █▀          ▄████▀   █▀    ▀█   ███   █▀    ██████████   ███    ███        ███    ███   ██████████  ▄████████▀  
    echo ▀                                                                                                        ███    ███        ███    ███                           

		     
                                echo Checking if all required redistributables are installed
			                                                                                                                        timeout /t 2 /nobreak > NULL
             	set "choice="
				:Choice2
	set /p choice=Do you already have VC Runtimes? (y/n): 
	if /i "%choice%"=="y" goto :skip
	if /i "%choice%"=="n" goto :no
	echo Invalid input. Please enter 'y' or 'n'.
	goto :CHOICE2
	:no
set INSTALLCHECK=0

:: Check if 2005 is installed (Check for msvcr80.dll)
if exist "%windir%\System32\msvcr80.dll" set /a INSTALLCHECK+=1
if exist "%windir%\SysWow64\msvcr80.dll" set /a INSTALLCHECK+=1

:: Check if 2008 is installed (Check for msvcr90.dll)
if exist "%windir%\System32\msvcr90.dll" set /a INSTALLCHECK+=1
if exist "%windir%\SysWow64\msvcr90.dll" set /a INSTALLCHECK+=1

:: Check if 2010 is installed (Check for msvcr100.dll)
if exist "%windir%\System32\msvcr100.dll" set /a INSTALLCHECK+=1
if exist "%windir%\SysWow64\msvcr100.dll" set /a INSTALLCHECK+=1

:: Check if 2012 is installed (Check for msvcr110.dll)
if exist "%windir%\System32\msvcr110.dll" set /a INSTALLCHECK+=1
if exist "%windir%\SysWow64\msvcr110.dll" set /a INSTALLCHECK+=1

:: Check if 2013 is installed (Check for msvcr120.dll)
if exist "%windir%\System32\msvcr120.dll" set /a INSTALLCHECK+=1
if exist "%windir%\SysWow64\msvcr120.dll" set /a INSTALLCHECK+=1

:: Check if 2015-2017-2019-2022 is installed (Check for msvcr140.dll)
if exist "%windir%\System32\msvcr140.dll" set /a INSTALLCHECK+=1
if exist "%windir%\SysWow64\msvcr140.dll" set /a INSTALLCHECK+=1

:: If all are found, skip installation
if %INSTALLCHECK%==12 goto :skip
if %INSTALLCHECK%==11 goto :skip
if %INSTALLCHECK%==10 goto :skip
if %INSTALLCHECK%==9 goto :skip
if %INSTALLCHECK%==8 goto :skip
if %INSTALLCHECK%==7 goto :skip



:missing
echo One or more redistributables are missing. Proceeding with installation...
goto :next1
:skip
echo All redistributables are already installed.
CD /d %~dp0
goto FULLEND

    :next1
    : TIMER REG
    
            CD /d %~dp0
            mkdir %temp%\VC
            echo Downloading VC Runtimes (This May Take A Momment)
            curl -L "https://www.dropbox.com/scl/fi/tzvstf8m51763bpkr5yi6/VC-RUNTIMES.zip?rlkey=8c40tdn5nuyad1yphnsp1lllc&st=723kzo0f&dl=1" -o "%temp%\VC.zip"
            powershell -Command "Expand-Archive -Path '%temp%\VC.zip' -DestinationPath '%temp%\VC'

:: directory to the unzipped folder
CD /d "%temp%\VC\VC RUNTIMES"

:: Install Visual C++ Redistributables
echo Installing Microsoft Visual C++ All-In-One Runtimes...
set IS_X64=0 && if "%PROCESSOR_ARCHITECTURE%"=="AMD64" (set IS_X64=1) else (if "%PROCESSOR_ARCHITEW6432%"=="AMD64" (set IS_X64=1))

if "%IS_X64%" == "1" goto X64

start /wait vcredist2005_x86.exe /q
        start /wait vcredist2008_x86.exe /qb
    start /wait vcredist2010_x86.exe /passive /norestart
start /wait vcredist2012_x86.exe /passive /norestart
    start /wait vcredist2013_x86.exe /passive /norestart
start /wait vcredist2015_2017_2019_2022_x86.exe /passive /norestart

goto END

:X64
start /wait vcredist2005_x86.exe /q
    start /wait vcredist2005_x64.exe /q
        start /wait vcredist2008_x86.exe /qb
        start /wait vcredist2008_x64.exe /qb
        start /wait vcredist2010_x86.exe /passive /norestart
            start /wait vcredist2010_x64.exe /passive /norestart
            start /wait vcredist2012_x86.exe /passive /norestart
        start /wait vcredist2012_x64.exe /passive /norestart
        start /wait vcredist2013_x86.exe /passive /norestart
        start /wait vcredist2013_x64.exe /passive /norestart
    start /wait vcredist2015_2017_2019_2022_x86.exe /passive /norestart
start /wait vcredist2015_2017_2019_2022_x64.exe /passive /norestart
cd %temp%
cls
echo VC Runtimes Done
timeout /t 2 /nobreak > NULL
goto next22
:FULLEND
echo Skipped!
cd %temp%
:next22
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel" /v "GlobalTimerResolutionRequests" /t REG_DWORD /d 1 /f
timeout /t 1 /nobreak > NULL
cls
echo Downloading Measuresleep
timeout /t 2 /nobreak > NULL
:: MeasureSleep.exe to C:\
curl -L "https://www.dropbox.com/scl/fi/35h9ds3zrl4l9xwq2g1y4/MeasureSleep.exe?rlkey=qtk1dvmtfut33npme6xw3v8pz&st=rmfboiro&dl=1" -o "C:\Lumin\MeasureSleep.exe"
echo Downloading Amit's Timer Res
curl -L "https://www.dropbox.com/scl/fi/fll2790szt3gonr0t0ow3/SetTimerResolution.exe?rlkey=5vt12ip075xtbvm1hr4iot73g&st=t2tnh3ev&dl=1" -o C:\Lumin\SetTimerResolution.exe
timeout /t 1 /nobreak > NULL
echo Downloads Finished
timeout /t 2 /nobreak > NULL
:no3
cls
set SHORTCUT_PATH=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\SetTimerResolution.lnk
set /p choice=What Would You Like To Set Your Timer Res Value? (5000+):
set TIMERRESVALUE=%choice%

:prompt3
set /p choice=Comirm This Is Correct %TIMERRESVALUE% (Y/N)
if /i "%choice%"=="y" goto :skip3
	if /i "%choice%"=="n" goto :no3
	goto :promp3
	    :skip3
	
powershell $s = New-Object -COM WScript.Shell; $sc = $s.CreateShortcut('%SHORTCUT_PATH%'); $sc.TargetPath = 'C:\Lumin\SetTimerResolution.exe'; $sc.Arguments = '--resolution %TIMERRESVALUE% --no-console'; $sc.WorkingDirectory = 'C:\Lumin'; $sc.Save()
echo Timer Shortcut Res Set To %TIMERRESVALUE%, Restart PC To Apply
timeout /t 4 /nobreak > NULL