@echo off
echo Removing Mixed Reality Portal, 3D Viewer, and Get Help if they are installed.
powershell -NoProfile -Command "Get-AppxPackage *MixedReality.Portal* | Remove-AppxPackage; Get-AppxPackage *Microsoft3DViewer* | Remove-AppxPackage; Get-AppxPackage *GetHelp* | Remove-AppxPackage"
echo Done.
