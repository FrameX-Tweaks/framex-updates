@echo off
sc query DiagTrack >nul 2>&1 && sc stop DiagTrack
sc query DiagTrack >nul 2>&1 && sc config DiagTrack start= disabled
echo DiagTrack set to disabled if it exists.
