@echo off
title FRAMEX TWEAKS - Services
color 0D
@echo off


:: AllJoyn Router Service
sc query AJRouter >nul 2>&1 && sc config AJRouter start= disabled >nul

:: App Readiness
sc query AppReadiness >nul 2>&1 && sc config AppReadiness start= disabled >nul

:: Application Layer Gateway Service
sc query ALG >nul 2>&1 && sc config ALG start= disabled >nul

:: AVCTP Service
sc query AVCTP >nul 2>&1 && sc config AVCTP start= disabled >nul

:: Background Intelligent Transfer Service
sc query BITS >nul 2>&1 && sc config BITS start= disabled >nul

:: Bluetooth Support Service
sc query bthserv >nul 2>&1 && sc config bthserv start= disabled >nul

:: BitLocker Drive Encryption Service
sc query BDESVC >nul 2>&1 && sc config BDESVC start= disabled >nul

:: Certificate Propagation
sc query CertPropSvc >nul 2>&1 && sc config CertPropSvc start= disabled >nul

:: Clipboard User Service
sc query cbdhsvc >nul 2>&1 && sc config cbdhsvc start= disabled >nul

:: Connected User Experiences and Telemetry
sc query DiagTrack >nul 2>&1 && sc config DiagTrack start= disabled >nul

:: Data Usage
sc query DusmSvc >nul 2>&1 && sc config DusmSvc start= disabled >nul

:: Diagnostic Services
sc query DPS >nul 2>&1 && sc config DPS start= disabled >nul

:: Distributed Link Tracking Client
sc query TrkWks >nul 2>&1 && sc config TrkWks start= disabled >nul

:: Downloaded Maps Manager
sc query MapsBroker >nul 2>&1 && sc config MapsBroker start= disabled >nul

:: GameInput
sc query GameInputSvc >nul 2>&1 && sc config GameInputSvc start= disabled >nul

:: Geolocation Service
sc query lfsvc >nul 2>&1 && sc config lfsvc start= disabled >nul

:: Microsoft Edge Elevation Service
sc query edgeupdate >nul 2>&1 && sc config edgeupdate start= disabled >nul
sc query edgeupdatem >nul 2>&1 && sc config edgeupdatem start= disabled >nul

:: Hyper-V related (disable only if not used)
sc query vmcompute >nul 2>&1 && sc config vmcompute start= disabled >nul
sc query vmms >nul 2>&1 && sc config vmms start= disabled >nul
sc query hvservice >nul 2>&1 && sc config hvservice start= disabled >nul

:: IP Helper
sc query iphlpsvc >nul 2>&1 && sc config iphlpsvc start= disabled >nul

:: Parental Controls
sc query WpcMonSvc >nul 2>&1 && sc config WpcMonSvc start= disabled >nul

:: Print Spooler
sc query Spooler >nul 2>&1 && sc config Spooler start= disabled >nul

:: Quality Windows Audio Video Experience
sc query QWAVE >nul 2>&1 && sc config QWAVE start= disabled >nul

:: Remote Registry
sc query RemoteRegistry >nul 2>&1 && sc config RemoteRegistry start= disabled >nul

:: Retail Demo Service
sc query RetailDemo >nul 2>&1 && sc config RetailDemo start= disabled >nul

:: Sync Host (OneDrive)
sc query OneSyncSvc >nul 2>&1 && sc config OneSyncSvc start= disabled >nul

:: SysMain
sc query SysMain >nul 2>&1 && sc config SysMain start= disabled >nul

:: TCP/IP NetBIOS Helper
sc query lmhosts >nul 2>&1 && sc config lmhosts start= disabled >nul

:: Telephony
sc query TapiSrv >nul 2>&1 && sc config TapiSrv start= disabled >nul

:: Themes
sc query Themes >nul 2>&1 && sc config Themes start= disabled >nul

:: Windows Search
sc query WSearch >nul 2>&1 && sc config WSearch start= disabled >nul

:: Xbox Services
sc query XboxGipSvc >nul 2>&1 && sc config XboxGipSvc start= disabled >nul
sc query XblAuthManager >nul 2>&1 && sc config XblAuthManager start= disabled >nul
sc query XblGameSave >nul 2>&1 && sc config XblGameSave start= disabled >nul
sc query XboxNetApiSvc >nul 2>&1 && sc config XboxNetApiSvc start= disabled >nul

:: Disable Game DVR / Game Bar (registry)
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR" /v AppCaptureEnabled /t REG_DWORD /d 0 /f
reg add "HKCU\System\GameConfigStore" /v GameDVR_Enabled /t REG_DWORD /d 0 /f



echo.
echo    Follow FrameX Tweaks
echo    Press any key to close...
pause >nul
