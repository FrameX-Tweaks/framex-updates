@echo off
title FRAMEX TWEAKS - Services
color 0D
@echo off
echo Reverting all services to default startup types...
echo.

:: AllJoyn Router Service
sc query AJRouter >nul 2>&1 && sc config AJRouter start= demand >nul

:: App Readiness
sc query AppReadiness >nul 2>&1 && sc config AppReadiness start= manual >nul

:: Application Layer Gateway Service
sc query ALG >nul 2>&1 && sc config ALG start= manual >nul

:: AVCTP Service
sc query AVCTP >nul 2>&1 && sc config AVCTP start= manual >nul

:: Background Intelligent Transfer Service
sc query BITS >nul 2>&1 && sc config BITS start= delayed-auto >nul

:: Bluetooth Support Service
sc query bthserv >nul 2>&1 && sc config bthserv start= manual >nul

:: BitLocker Drive Encryption Service
sc query BDESVC >nul 2>&1 && sc config BDESVC start= manual >nul

:: Certificate Propagation
sc query CertPropSvc >nul 2>&1 && sc config CertPropSvc start= manual >nul

:: Clipboard User Service
sc query cbdhsvc >nul 2>&1 && sc config cbdhsvc start= delayed-auto >nul

:: Connected User Experiences and Telemetry
sc query DiagTrack >nul 2>&1 && sc config DiagTrack start= auto >nul

:: Data Usage
sc query DusmSvc >nul 2>&1 && sc config DusmSvc start= manual >nul

:: Diagnostic Services
sc query DPS >nul 2>&1 && sc config DPS start= auto >nul

:: Distributed Link Tracking Client
sc query TrkWks >nul 2>&1 && sc config TrkWks start= auto >nul

:: Downloaded Maps Manager
sc query MapsBroker >nul 2>&1 && sc config MapsBroker start= manual >nul

:: GameInput
sc query GameInputSvc >nul 2>&1 && sc config GameInputSvc start= manual >nul

:: Geolocation Service
sc query lfsvc >nul 2>&1 && sc config lfsvc start= manual >nul

:: Microsoft Edge Elevation Service
sc query edgeupdate >nul 2>&1 && sc config edgeupdate start= auto >nul
sc query edgeupdatem >nul 2>&1 && sc config edgeupdatem start= auto >nul

:: Hyper-V services (default = manual)
sc query vmcompute >nul 2>&1 && sc config vmcompute start= manual >nul
sc query vmms >nul 2>&1 && sc config vmms start= manual >nul
sc query hvservice >nul 2>&1 && sc config hvservice start= manual >nul

:: IP Helper
sc query iphlpsvc >nul 2>&1 && sc config iphlpsvc start= auto >nul

:: Parental Controls
sc query WpcMonSvc >nul 2>&1 && sc config WpcMonSvc start= manual >nul

:: Print Spooler
sc query Spooler >nul 2>&1 && sc config Spooler start= auto >nul

:: Quality Windows Audio Video Experience
sc query QWAVE >nul 2>&1 && sc config QWAVE start= manual >nul

:: Remote Registry
sc query RemoteRegistry >nul 2>&1 && sc config RemoteRegistry start= manual >nul

:: Retail Demo Service
sc query RetailDemo >nul 2>&1 && sc config RetailDemo start= manual >nul

:: Sync Host (OneDrive)
sc query OneSyncSvc >nul 2>&1 && sc config OneSyncSvc start= delayed-auto >nul

:: SysMain
sc query SysMain >nul 2>&1 && sc config SysMain start= auto >nul

:: TCP/IP NetBIOS Helper
sc query lmhosts >nul 2>&1 && sc config lmhosts start= auto >nul

:: Telephony
sc query TapiSrv >nul 2>&1 && sc config TapiSrv start= manual >nul

:: Themes
sc query Themes >nul 2>&1 && sc config Themes start= auto >nul

:: Windows Search
sc query WSearch >nul 2>&1 && sc config WSearch start= delayed-auto >nul

:: Xbox Services
sc query XboxGipSvc >nul 2>&1 && sc config XboxGipSvc start= manual >nul
sc query XblAuthManager >nul 2>&1 && sc config XblAuthManager start= manual >nul
sc query XblGameSave >nul 2>&1 && sc config XblGameSave start= manual >nul
sc query XboxNetApiSvc >nul 2>&1 && sc config XboxNetApiSvc start= manual >nul

:: Restore Game DVR / Game Bar default registry
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR" /v AppCaptureEnabled /t REG_DWORD /d 1 /f
reg add "HKCU\System\GameConfigStore" /v GameDVR_Enabled /t REG_DWORD /d 1 /f

echo.
echo Revert complete.
pause

echo.
echo    Follow FrameX Tweaks
