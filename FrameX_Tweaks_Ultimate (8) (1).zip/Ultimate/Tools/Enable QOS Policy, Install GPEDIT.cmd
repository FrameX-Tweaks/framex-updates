@echo off
setlocal EnableDelayedExpansion

REM Check for administrator privileges
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo.
    echo ERROR: Administrator privileges required!
    echo Please run this script as Administrator.
    echo.
    pause
    exit /b 1
)

echo ============================================================================
echo QoS Policy Configuration Script
echo ============================================================================
echo.

REM ============================================================================
REM Step 1: Check and Install Group Policy Editor (gpedit.msc)
REM ============================================================================
echo [1/6] Checking for Group Policy Editor...

REM Check if gpedit.msc exists
if exist "%SystemRoot%\System32\gpedit.msc" (
    echo       - Group Policy Editor is already installed
    echo.
    goto :skip_gpedit_install
)

echo       - Group Policy Editor not found
echo       - Installing Group Policy Editor for Windows Home...
echo.

REM Detect Windows architecture
if exist "%SystemRoot%\SysWOW64" (
    set ARCH=x64
) else (
    set ARCH=x86
)

echo       - Detected architecture: !ARCH!
echo       - This may take a few minutes...
echo.

REM Create temporary batch file for DISM operations
echo Creating installation script...

(
echo @echo off
echo echo Installing Group Policy Editor components...
echo.
echo FOR %%%%i IN ^(
echo     Microsoft-Windows-GroupPolicy-ClientTools-Package~31bf3856ad364e35~amd64~~10.0.19041.1
echo     Microsoft-Windows-GroupPolicy-ClientExtensions-Package~31bf3856ad364e35~amd64~~10.0.19041.1
echo ^) DO ^(
echo     echo Installing: %%%%i
echo     DISM /Online /Add-Package /PackageName:%%%%i /NoRestart
echo ^)
echo.
echo echo Registering DLL files...
echo FOR %%%%i IN ^(
echo     gpedit.dll
echo     fde.dll
echo     gpedit.msc
echo     gptext.dll
echo     wsecedit.dll
echo     scecli.dll
echo     appmgmts.dll
echo     fdeploy.dll
echo ^) DO ^(
echo     IF EXIST "%%SystemRoot%%\System32\%%%%i" ^(
echo         regsvr32 /s "%%SystemRoot%%\System32\%%%%i"
echo     ^)
echo ^)
echo.
echo echo Group Policy Editor installation completed.
) > "%TEMP%\install_gpedit.bat"

REM Try DISM method first (for Windows 10/11)
echo       - Attempting DISM installation method...
call "%TEMP%\install_gpedit.bat" >nul 2>&1

REM Alternative method: Copy files from WinSxS
if not exist "%SystemRoot%\System32\gpedit.msc" (
    echo       - DISM method not available, using file copy method...
    
    REM Search for gpedit files in WinSxS and copy them
    for /f "delims=" %%i in ('dir /b /s "%SystemRoot%\WinSxS\gpedit.dll" 2^>nul') do (
        copy "%%i" "%SystemRoot%\System32\" >nul 2>&1
    )
    
    for /f "delims=" %%i in ('dir /b /s "%SystemRoot%\WinSxS\gpedit.msc" 2^>nul') do (
        copy "%%i" "%SystemRoot%\System32\" >nul 2>&1
    )
    
    for /f "delims=" %%i in ('dir /b /s "%SystemRoot%\WinSxS\fde.dll" 2^>nul') do (
        copy "%%i" "%SystemRoot%\System32\" >nul 2>&1
    )
    
    for /f "delims=" %%i in ('dir /b /s "%SystemRoot%\WinSxS\gptext.dll" 2^>nul') do (
        copy "%%i" "%SystemRoot%\System32\" >nul 2>&1
    )
    
    REM Register the DLLs
    if exist "%SystemRoot%\System32\gpedit.dll" regsvr32 /s "%SystemRoot%\System32\gpedit.dll"
    if exist "%SystemRoot%\System32\fde.dll" regsvr32 /s "%SystemRoot%\System32\fde.dll"
    if exist "%SystemRoot%\System32\gptext.dll" regsvr32 /s "%SystemRoot%\System32\gptext.dll"
)

REM Clean up temporary file
del "%TEMP%\install_gpedit.bat" >nul 2>&1

REM Final check
if exist "%SystemRoot%\System32\gpedit.msc" (
    echo       - Group Policy Editor installed successfully!
    echo       - You can now run gpedit.msc
) else (
    echo       - Warning: Automatic installation failed
    echo       - You may need to install Group Policy Editor manually
    echo       - Note: QoS policies will still work via registry settings
)
echo.

:skip_gpedit_install

REM ============================================================================
REM Step 2: Enable QoS Packet Scheduler Service
REM ============================================================================
echo [2/6] Configuring QoS Packet Scheduler Service...
sc config Psched start= auto >nul 2>&1
if %errorLevel% equ 0 (
    echo       - Service set to automatic startup
) else (
    echo       - Warning: Could not configure service startup
)

net start Psched >nul 2>&1
if %errorLevel% equ 0 (
    echo       - Service started successfully
) else (
    sc query Psched | find "RUNNING" >nul
    if !errorLevel! equ 0 (
        echo       - Service already running
    ) else (
        echo       - Warning: Could not start service
    )
)
echo.

REM ============================================================================
REM Step 3: Remove bandwidth reservation limit (if exists)
REM ============================================================================
echo [3/6] Removing QoS bandwidth reservation limit...
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Psched" /v NonBestEffortLimit /t REG_DWORD /d 0 /f >nul 2>&1
if %errorLevel% equ 0 (
    echo       - Bandwidth reservation limit set to 0%% (unrestricted)
) else (
    echo       - Warning: Could not modify registry setting
)
echo.

REM ============================================================================
REM Step 4: Enable QoS on all network adapters
REM ============================================================================
echo [4/6] Enabling QoS Packet Scheduler on network adapters...
set adapter_count=0

for /f "tokens=1,2,*" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control\Class\{4D36E972-E325-11CE-BFC1-08002BE10318}" /s /f "DriverDesc" ^| find "DriverDesc"') do (
    set adapter_path=%%a
    set adapter_path=!adapter_path:HKEY_LOCAL_MACHINE\=HKLM\!
    
    REM Remove the \DriverDesc part
    for /f "delims=\" %%x in ("!adapter_path!") do set adapter_path=%%x
    
    REM Check if this is a valid adapter key (has 4 digits)
    echo !adapter_path! | findstr /r "\\[0-9][0-9][0-9][0-9]$" >nul
    if !errorLevel! equ 0 (
        REM Add QoS binding
        reg add "!adapter_path!\Ndi\Interfaces" /v LowerRange /t REG_SZ /d "ethernet" /f >nul 2>&1
        reg add "!adapter_path!\Ndi\Interfaces" /v UpperRange /t REG_SZ /d "ndis5" /f >nul 2>&1
        set /a adapter_count+=1
    )
)

if !adapter_count! gtr 0 (
    echo       - QoS enabled on network adapters
) else (
    echo       - No changes needed for network adapters
)
echo.

REM ============================================================================
REM Step 5: Configure QoS registry settings
REM ============================================================================
echo [5/6] Configuring QoS registry settings...

REM Enable QoS globally
reg add "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\QoS" /v "Do not use NLA" /t REG_SZ /d "1" /f >nul 2>&1

REM Configure QoS for better performance
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\QoS" /f >nul 2>&1
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\QoS" /v "Application DSCP Marking Request" /t REG_SZ /d "Allowed" /f >nul 2>&1
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\QoS" /v "Tcp Autotuning Level" /t REG_SZ /d "Normal" /f >nul 2>&1

echo       - QoS registry settings configured
echo.

REM ============================================================================
REM Step 6: Configure network adapter QoS settings via PowerShell
REM ============================================================================
echo [6/6] Configuring QoS on active network adapters...

powershell -Command "Get-NetAdapter | Where-Object {$_.Status -eq 'Up'} | ForEach-Object { Enable-NetAdapterQos -Name $_.Name -ErrorAction SilentlyContinue }" >nul 2>&1

if %errorLevel% equ 0 (
    echo       - QoS enabled on active network adapters
) else (
    echo       - Note: PowerShell configuration may require Windows 8/Server 2012 or later
)
echo.


REM ============================================================================
REM Completion and recommendations
REM ============================================================================
echo ============================================================================
echo Configuration Complete!
echo ============================================================================
echo.
echo QoS has been configured on your system. Here are some notes:
echo.
echo - Group Policy Editor (gpedit.msc) has been installed/verified
echo - The QoS Packet Scheduler service is now running
echo - Bandwidth reservation limit has been removed
echo - QoS is enabled on network adapters
echo - Default QoS policies have been applied
echo.
echo RECOMMENDATIONS:
echo - A system restart is recommended for all changes to take effect
echo - You can now configure QoS policies via gpedit.msc
echo.
echo.
pause
