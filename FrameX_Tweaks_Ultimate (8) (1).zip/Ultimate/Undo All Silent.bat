@echo off
set "HERE=%~dp0"
if exist "%HERE%Services\Revert.bat" call "%HERE%Services\Revert.bat"
if exist "%HERE%Regedit\Revert Defaults.reg" reg import "%HERE%Regedit\Revert Defaults.reg" >nul 2>&1
if exist "%HERE%Clipzz\Revert Clipzz.reg" reg import "%HERE%Clipzz\Revert Clipzz.reg" >nul 2>&1
sc query DiagTrack >nul 2>&1 && sc config DiagTrack start= auto >nul 2>&1
powercfg -h on >nul 2>&1
powercfg -restoredefaultschemes >nul 2>&1
powercfg -setactive SCHEME_BALANCED >nul 2>&1
reg add "HKCU\Control Panel\Mouse" /v MouseSpeed /t REG_SZ /d 1 /f >nul
reg add "HKCU\Control Panel\Mouse" /v MouseThreshold1 /t REG_SZ /d 6 /f >nul
reg add "HKCU\Control Panel\Mouse" /v MouseThreshold2 /t REG_SZ /d 10 /f >nul
reg add "HKCU\Control Panel\Keyboard" /v KeyboardDelay /t REG_SZ /d 1 /f >nul
reg add "HKCU\Control Panel\Keyboard" /v KeyboardSpeed /t REG_SZ /d 31 /f >nul
exit /b 0
