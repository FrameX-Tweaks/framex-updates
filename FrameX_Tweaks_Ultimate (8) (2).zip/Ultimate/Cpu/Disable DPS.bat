@echo off
sc query DPS >nul 2>&1 && sc stop DPS >nul 2>&1
sc query DPS >nul 2>&1 && sc config DPS start= disabled >nul 2>&1
exit /b 0
