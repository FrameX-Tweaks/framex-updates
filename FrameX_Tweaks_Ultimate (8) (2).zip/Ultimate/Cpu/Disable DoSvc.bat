@echo off
sc query DoSvc >nul 2>&1 && sc stop DoSvc >nul 2>&1
sc query DoSvc >nul 2>&1 && sc config DoSvc start= disabled >nul 2>&1
exit /b 0
