@echo off
sc query Fax >nul 2>&1 && sc stop Fax >nul 2>&1
sc query Fax >nul 2>&1 && sc config Fax start= disabled >nul 2>&1
exit /b 0
