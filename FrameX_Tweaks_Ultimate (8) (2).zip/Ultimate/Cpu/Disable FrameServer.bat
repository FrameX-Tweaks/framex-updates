@echo off
sc query FrameServer >nul 2>&1 && sc stop FrameServer >nul 2>&1
sc query FrameServer >nul 2>&1 && sc config FrameServer start= disabled >nul 2>&1
exit /b 0
