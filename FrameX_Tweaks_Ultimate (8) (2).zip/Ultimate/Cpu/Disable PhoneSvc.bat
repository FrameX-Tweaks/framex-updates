@echo off
sc query PhoneSvc >nul 2>&1 && sc stop PhoneSvc >nul 2>&1
sc query PhoneSvc >nul 2>&1 && sc config PhoneSvc start= disabled >nul 2>&1
exit /b 0
