@echo off
sc query RemoteAccess >nul 2>&1 && sc stop RemoteAccess >nul 2>&1
sc query RemoteAccess >nul 2>&1 && sc config RemoteAccess start= disabled >nul 2>&1
exit /b 0
