@echo off
sc query RemoteRegistry >nul 2>&1 && sc stop RemoteRegistry >nul 2>&1
sc query RemoteRegistry >nul 2>&1 && sc config RemoteRegistry start= disabled >nul 2>&1
exit /b 0
