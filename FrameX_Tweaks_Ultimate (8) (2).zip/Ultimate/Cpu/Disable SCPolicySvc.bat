@echo off
sc query SCPolicySvc >nul 2>&1 && sc stop SCPolicySvc >nul 2>&1
sc query SCPolicySvc >nul 2>&1 && sc config SCPolicySvc start= disabled >nul 2>&1
exit /b 0
