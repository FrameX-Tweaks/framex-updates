@echo off
sc query SharedAccess >nul 2>&1 && sc stop SharedAccess >nul 2>&1
sc query SharedAccess >nul 2>&1 && sc config SharedAccess start= disabled >nul 2>&1
exit /b 0
