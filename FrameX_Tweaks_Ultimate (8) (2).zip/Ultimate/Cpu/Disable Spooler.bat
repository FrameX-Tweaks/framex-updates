@echo off
sc query Spooler >nul 2>&1 && sc stop Spooler >nul 2>&1
sc query Spooler >nul 2>&1 && sc config Spooler start= disabled >nul 2>&1
exit /b 0
