@echo off
sc query SysMain >nul 2>&1 && sc stop SysMain >nul 2>&1
sc query SysMain >nul 2>&1 && sc config SysMain start= disabled >nul 2>&1
exit /b 0
