@echo off
sc query TokenBroker >nul 2>&1 && sc stop TokenBroker >nul 2>&1
sc query TokenBroker >nul 2>&1 && sc config TokenBroker start= disabled >nul 2>&1
exit /b 0
