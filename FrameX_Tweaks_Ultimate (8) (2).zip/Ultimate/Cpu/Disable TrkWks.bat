@echo off
sc query TrkWks >nul 2>&1 && sc stop TrkWks >nul 2>&1
sc query TrkWks >nul 2>&1 && sc config TrkWks start= disabled >nul 2>&1
exit /b 0
