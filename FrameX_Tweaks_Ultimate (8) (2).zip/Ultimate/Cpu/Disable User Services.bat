@echo off
for /f "tokens=2 delims=:" %%S in ('sc query state^= all ^| findstr /I "SERVICE_NAME: CDPUserSvc"') do (
  sc stop %%S >nul 2>&1
  sc config %%S start= disabled >nul 2>&1
)
for /f "tokens=2 delims=:" %%S in ('sc query state^= all ^| findstr /I "SERVICE_NAME: OneSyncSvc"') do (
  sc stop %%S >nul 2>&1
  sc config %%S start= disabled >nul 2>&1
)
for /f "tokens=2 delims=:" %%S in ('sc query state^= all ^| findstr /I "SERVICE_NAME: PimIndexMaintenanceSvc"') do (
  sc stop %%S >nul 2>&1
  sc config %%S start= disabled >nul 2>&1
)
for /f "tokens=2 delims=:" %%S in ('sc query state^= all ^| findstr /I "SERVICE_NAME: UnistoreSvc"') do (
  sc stop %%S >nul 2>&1
  sc config %%S start= disabled >nul 2>&1
)
for /f "tokens=2 delims=:" %%S in ('sc query state^= all ^| findstr /I "SERVICE_NAME: UserDataSvc"') do (
  sc stop %%S >nul 2>&1
  sc config %%S start= disabled >nul 2>&1
)
for /f "tokens=2 delims=:" %%S in ('sc query state^= all ^| findstr /I "SERVICE_NAME: BcastDVRUserService"') do (
  sc stop %%S >nul 2>&1
  sc config %%S start= disabled >nul 2>&1
)
for /f "tokens=2 delims=:" %%S in ('sc query state^= all ^| findstr /I "SERVICE_NAME: CaptureService"') do (
  sc stop %%S >nul 2>&1
  sc config %%S start= disabled >nul 2>&1
)
for /f "tokens=2 delims=:" %%S in ('sc query state^= all ^| findstr /I "SERVICE_NAME: DevicePickerUserSvc"') do (
  sc stop %%S >nul 2>&1
  sc config %%S start= disabled >nul 2>&1
)
for /f "tokens=2 delims=:" %%S in ('sc query state^= all ^| findstr /I "SERVICE_NAME: DevicesFlowUserSvc"') do (
  sc stop %%S >nul 2>&1
  sc config %%S start= disabled >nul 2>&1
)
for /f "tokens=2 delims=:" %%S in ('sc query state^= all ^| findstr /I "SERVICE_NAME: ConsentUxUserSvc"') do (
  sc stop %%S >nul 2>&1
  sc config %%S start= disabled >nul 2>&1
)
for /f "tokens=2 delims=:" %%S in ('sc query state^= all ^| findstr /I "SERVICE_NAME: CredentialEnrollmentManagerUserSvc"') do (
  sc stop %%S >nul 2>&1
  sc config %%S start= disabled >nul 2>&1
)
for /f "tokens=2 delims=:" %%S in ('sc query state^= all ^| findstr /I "SERVICE_NAME: DeviceAssociationBrokerSvc"') do (
  sc stop %%S >nul 2>&1
  sc config %%S start= disabled >nul 2>&1
)
for /f "tokens=2 delims=:" %%S in ('sc query state^= all ^| findstr /I "SERVICE_NAME: WpnUserSvc"') do (
  sc stop %%S >nul 2>&1
  sc config %%S start= disabled >nul 2>&1
)
for /f "tokens=2 delims=:" %%S in ('sc query state^= all ^| findstr /I "SERVICE_NAME: cbdhsvc"') do (
  sc stop %%S >nul 2>&1
  sc config %%S start= disabled >nul 2>&1
)
for /f "tokens=2 delims=:" %%S in ('sc query state^= all ^| findstr /I "SERVICE_NAME: UdkUserSvc"') do (
  sc stop %%S >nul 2>&1
  sc config %%S start= disabled >nul 2>&1
)
for /f "tokens=2 delims=:" %%S in ('sc query state^= all ^| findstr /I "SERVICE_NAME: PrintWorkflowUserSvc"') do (
  sc stop %%S >nul 2>&1
  sc config %%S start= disabled >nul 2>&1
)
exit /b 0
