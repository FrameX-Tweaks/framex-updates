@echo off
sc query WdiServiceHost >nul 2>&1 && sc stop WdiServiceHost >nul 2>&1
sc query WdiServiceHost >nul 2>&1 && sc config WdiServiceHost start= disabled >nul 2>&1
exit /b 0
