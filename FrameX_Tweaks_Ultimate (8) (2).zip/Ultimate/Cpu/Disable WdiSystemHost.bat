@echo off
sc query WdiSystemHost >nul 2>&1 && sc stop WdiSystemHost >nul 2>&1
sc query WdiSystemHost >nul 2>&1 && sc config WdiSystemHost start= disabled >nul 2>&1
exit /b 0
