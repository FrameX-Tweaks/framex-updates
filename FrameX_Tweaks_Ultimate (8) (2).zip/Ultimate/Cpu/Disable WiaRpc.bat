@echo off
sc query WiaRpc >nul 2>&1 && sc stop WiaRpc >nul 2>&1
sc query WiaRpc >nul 2>&1 && sc config WiaRpc start= disabled >nul 2>&1
exit /b 0
