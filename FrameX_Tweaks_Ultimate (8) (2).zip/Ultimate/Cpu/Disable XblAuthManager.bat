@echo off
sc query XblAuthManager >nul 2>&1 && sc stop XblAuthManager >nul 2>&1
sc query XblAuthManager >nul 2>&1 && sc config XblAuthManager start= disabled >nul 2>&1
exit /b 0
