@echo off
sc query XblGameSave >nul 2>&1 && sc stop XblGameSave >nul 2>&1
sc query XblGameSave >nul 2>&1 && sc config XblGameSave start= disabled >nul 2>&1
exit /b 0
