@echo off
sc query diagnosticshub.standardcollector.service >nul 2>&1 && sc stop diagnosticshub.standardcollector.service >nul 2>&1
sc query diagnosticshub.standardcollector.service >nul 2>&1 && sc config diagnosticshub.standardcollector.service start= disabled >nul 2>&1
exit /b 0
