@echo off
sc query lfsvc >nul 2>&1 && sc stop lfsvc >nul 2>&1
sc query lfsvc >nul 2>&1 && sc config lfsvc start= disabled >nul 2>&1
exit /b 0
