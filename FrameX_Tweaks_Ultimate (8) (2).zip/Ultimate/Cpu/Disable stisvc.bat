@echo off
sc query stisvc >nul 2>&1 && sc stop stisvc >nul 2>&1
sc query stisvc >nul 2>&1 && sc config stisvc start= disabled >nul 2>&1
exit /b 0
