@echo off
sc query upnphost >nul 2>&1 && sc stop upnphost >nul 2>&1
sc query upnphost >nul 2>&1 && sc config upnphost start= disabled >nul 2>&1
exit /b 0
