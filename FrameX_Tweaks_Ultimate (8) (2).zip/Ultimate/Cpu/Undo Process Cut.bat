@echo off
sc query Spooler >nul 2>&1 && sc config Spooler start= demand >nul 2>&1
sc query DoSvc >nul 2>&1 && sc config DoSvc start= demand >nul 2>&1
sc query TokenBroker >nul 2>&1 && sc config TokenBroker start= demand >nul 2>&1
sc query TrkWks >nul 2>&1 && sc config TrkWks start= demand >nul 2>&1
sc query SSDPSRV >nul 2>&1 && sc config SSDPSRV start= demand >nul 2>&1
sc query upnphost >nul 2>&1 && sc config upnphost start= demand >nul 2>&1
sc query WMPNetworkSvc >nul 2>&1 && sc config WMPNetworkSvc start= demand >nul 2>&1
sc query RemoteAccess >nul 2>&1 && sc config RemoteAccess start= demand >nul 2>&1
sc query icssvc >nul 2>&1 && sc config icssvc start= demand >nul 2>&1
sc query SCardSvr >nul 2>&1 && sc config SCardSvr start= demand >nul 2>&1
sc query SCPolicySvc >nul 2>&1 && sc config SCPolicySvc start= demand >nul 2>&1
sc query WpcMonSvc >nul 2>&1 && sc config WpcMonSvc start= demand >nul 2>&1
sc query FrameServer >nul 2>&1 && sc config FrameServer start= demand >nul 2>&1
sc query stisvc >nul 2>&1 && sc config stisvc start= demand >nul 2>&1
sc query WiaRpc >nul 2>&1 && sc config WiaRpc start= demand >nul 2>&1
sc query PrintNotify >nul 2>&1 && sc config PrintNotify start= demand >nul 2>&1
sc query DPS >nul 2>&1 && sc config DPS start= demand >nul 2>&1
sc query WdiServiceHost >nul 2>&1 && sc config WdiServiceHost start= demand >nul 2>&1
sc query WdiSystemHost >nul 2>&1 && sc config WdiSystemHost start= demand >nul 2>&1
sc query diagnosticshub.standardcollector.service >nul 2>&1 && sc config diagnosticshub.standardcollector.service start= demand >nul 2>&1
for /f "tokens=2 delims=:" %%S in ('sc query state^= all ^| findstr /I "SERVICE_NAME: CDPUserSvc"') do sc config %%S start= demand >nul 2>&1
for /f "tokens=2 delims=:" %%S in ('sc query state^= all ^| findstr /I "SERVICE_NAME: OneSyncSvc"') do sc config %%S start= demand >nul 2>&1
for /f "tokens=2 delims=:" %%S in ('sc query state^= all ^| findstr /I "SERVICE_NAME: PimIndexMaintenanceSvc"') do sc config %%S start= demand >nul 2>&1
for /f "tokens=2 delims=:" %%S in ('sc query state^= all ^| findstr /I "SERVICE_NAME: UnistoreSvc"') do sc config %%S start= demand >nul 2>&1
for /f "tokens=2 delims=:" %%S in ('sc query state^= all ^| findstr /I "SERVICE_NAME: UserDataSvc"') do sc config %%S start= demand >nul 2>&1
for /f "tokens=2 delims=:" %%S in ('sc query state^= all ^| findstr /I "SERVICE_NAME: BcastDVRUserService"') do sc config %%S start= demand >nul 2>&1
for /f "tokens=2 delims=:" %%S in ('sc query state^= all ^| findstr /I "SERVICE_NAME: CaptureService"') do sc config %%S start= demand >nul 2>&1
for /f "tokens=2 delims=:" %%S in ('sc query state^= all ^| findstr /I "SERVICE_NAME: DevicePickerUserSvc"') do sc config %%S start= demand >nul 2>&1
for /f "tokens=2 delims=:" %%S in ('sc query state^= all ^| findstr /I "SERVICE_NAME: DevicesFlowUserSvc"') do sc config %%S start= demand >nul 2>&1
for /f "tokens=2 delims=:" %%S in ('sc query state^= all ^| findstr /I "SERVICE_NAME: ConsentUxUserSvc"') do sc config %%S start= demand >nul 2>&1
for /f "tokens=2 delims=:" %%S in ('sc query state^= all ^| findstr /I "SERVICE_NAME: CredentialEnrollmentManagerUserSvc"') do sc config %%S start= demand >nul 2>&1
for /f "tokens=2 delims=:" %%S in ('sc query state^= all ^| findstr /I "SERVICE_NAME: DeviceAssociationBrokerSvc"') do sc config %%S start= demand >nul 2>&1
for /f "tokens=2 delims=:" %%S in ('sc query state^= all ^| findstr /I "SERVICE_NAME: WpnUserSvc"') do sc config %%S start= demand >nul 2>&1
for /f "tokens=2 delims=:" %%S in ('sc query state^= all ^| findstr /I "SERVICE_NAME: cbdhsvc"') do sc config %%S start= demand >nul 2>&1
for /f "tokens=2 delims=:" %%S in ('sc query state^= all ^| findstr /I "SERVICE_NAME: UdkUserSvc"') do sc config %%S start= demand >nul 2>&1
for /f "tokens=2 delims=:" %%S in ('sc query state^= all ^| findstr /I "SERVICE_NAME: PrintWorkflowUserSvc"') do sc config %%S start= demand >nul 2>&1
exit /b 0
