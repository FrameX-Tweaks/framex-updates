@echo off
title FRAMEX TWEAKS
color 0D
echo.
echo    ========================================
echo              FRAMEX TWEAKS
echo    ========================================
echo.
if /I "%~1"=="REG" (
  echo    Importing %~nx2
  reg import "%~2"
  echo.
  echo    Done.
  echo    Press any key to close...
  pause >nul
  exit /b 0
)
if /I "%~1"=="EXE" (
  echo    Opening %~nx2
  start "" "%~2"
  echo.
  echo    Done.
  echo    Press any key to close...
  pause >nul
  exit /b 0
)
if /I "%~1"=="POW" (
  echo    Importing power plan %~nx2
  powercfg -import "%~2"
  echo.
  echo    Done.
  echo    Press any key to close...
  pause >nul
  exit /b 0
)
echo    Running %~nx1
echo.
call "%~1" %2 %3 %4 %5
echo.
echo    ========================================
echo              FRAMEX TWEAKS
echo    ========================================
echo    Finished.
echo    Press any key to close...
pause >nul
exit /b 0
