@echo off
title FRAMEX TWEAKS - Untweak All
color 0D
echo.
echo    ========================================
echo              FRAMEX TWEAKS
echo           UNTWEAK ALL
echo    ========================================
echo.
set "HERE=%~dp0"
echo    Reverting services...
if exist "%HERE%Services\Revert.bat" call "%HERE%Services\Revert.bat"
echo    Reverting registry defaults...
if exist "%HERE%Regedit\Revert Defaults.reg" reg import "%HERE%Regedit\Revert Defaults.reg"
echo    Restoring power plans...
powercfg -h on >nul 2>&1
powercfg -restoredefaultschemes >nul 2>&1
powercfg -setactive SCHEME_BALANCED >nul 2>&1
bcdedit /set disabledynamictick yes >nul 2>&1
echo.
echo    Restoring mouse and keyboard defaults...
if exist "%HERE%Input\Restore Input Defaults.bat" call "%HERE%Input\Restore Input Defaults.bat"
echo    Done. Restart the PC so every change finishes.
echo    Press any key to close...
pause >nul
exit /b 0
